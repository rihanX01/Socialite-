# Hush

A calm launcher for social media. Original code, fully on-device: no account, no backend, no analytics, no subscription.

## Build without a PC (GitHub Actions)
Push this project to a private GitHub repo. The workflow in `.github/workflows/build.yml` builds the APK; download it from the Actions tab (artifact `Hush-debug-apk`).

## Build (Android Studio)
1. Install Android Studio, then File > Open and pick this folder. Let Gradle sync (it downloads what it needs).
2. Plug in a phone (USB debugging on) and press Run, or Build > Build APK(s) to get an installable debug APK.

## What it does
- Opens Instagram, YouTube, Facebook, Reddit and X in a clean in-app browser.
- Hides Reels / Shorts and sponsored posts (rules live in `Platforms.kt`).
- Daily time limit per app, and a nightly downtime schedule.
- A five-second breathing pause before an app opens (can be switched off).
- Time is counted only while the app is on screen; video stops when you leave.

## Maintenance
Site selectors in `Platforms.kt` break when a site changes its markup. That file is the one to keep updated.

## Not included (on purpose, for v1)
Accessibility-based blocking of other installed apps, VPN web filter, notification rerouting, device-admin uninstall lock, parent/child linking, widgets. Each asks for a powerful permission; add them only if you need them.
