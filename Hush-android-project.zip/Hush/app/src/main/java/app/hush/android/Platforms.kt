package app.hush.android

import org.json.JSONArray
import org.json.JSONObject

data class Platform(
    val id: String,
    val name: String,
    val url: String,
    val color: String,
    val hosts: List<String>,
    val shortsLabel: String = "",   // "" = platform has no short-video feed to hide
    val shortsCss: String = "",
    val shortsPath: String = "",    // regex; matching pages bounce back to "/"
    val adsCss: String = "",
    val postSel: String = ""        // posts scanned for a "Sponsored" label
)

/**
 * Site rules. Social sites change their markup often, so selectors here are the
 * part that will need occasional upkeep. Everything else is stable.
 */
object Platforms {
    val all = listOf(
        Platform(
            "instagram", "Instagram", "https://www.instagram.com/", "#e1306c",
            listOf("instagram.com"),
            shortsLabel = "Reels",
            shortsCss = """a[href^="/reels"],a[href*="/reels/"]{display:none!important}""",
            shortsPath = "^/reels?(/|\$)",
            postSel = "article"
        ),
        Platform(
            "youtube", "YouTube", "https://m.youtube.com/", "#ff4e45",
            listOf("youtube.com", "youtu.be", "google.com"),
            shortsLabel = "Shorts",
            shortsCss = """ytm-shorts-lockup-view-model,ytm-shorts-lockup-view-model-v2,ytm-reel-shelf-renderer,a[href^="/shorts"]{display:none!important}ytm-pivot-bar-item-renderer:has(a[href="/shorts"]){display:none!important}""",
            shortsPath = "^/shorts",
            adsCss = """ytm-promoted-sparkles-web-renderer,ytm-companion-slot,ad-slot-renderer,ytm-ad-slot-renderer{display:none!important}"""
        ),
        Platform(
            "facebook", "Facebook", "https://m.facebook.com/", "#4c8dff",
            listOf("facebook.com"),
            shortsLabel = "Reels",
            shortsCss = """a[href*="/reel/"],a[href*="/reels/"],a[href^="/watch"]{display:none!important}""",
            shortsPath = "^/(reel|reels|watch)(/|\$)",
            postSel = "article"
        ),
        Platform(
            "reddit", "Reddit", "https://www.reddit.com/", "#ff6a33",
            listOf("reddit.com"),
            adsCss = """shreddit-ad-post,[data-testid="ad-post"],.promotedlink{display:none!important}"""
        ),
        Platform(
            "x", "X", "https://x.com/", "#c9ced6",
            listOf("x.com", "twitter.com"),
            postSel = """[data-testid="cellInnerDiv"]"""
        )
    )

    fun byId(id: String) = all.firstOrNull { it.id == id }

    private val LABELS = listOf(
        "sponsored", "promoted", "ad", "gesponsert", "patrocinado",
        "sponsorisé", "sponsorizzato", "anuncio"
    )

    fun script(p: Platform, shorts: Boolean, ads: Boolean): String {
        val cfg = JSONObject()
            .put("shorts", shorts && p.shortsLabel.isNotEmpty())
            .put("ads", ads)
            .put("shortsCss", p.shortsCss).put("adsCss", p.adsCss)
            .put("shortsPath", p.shortsPath).put("postSel", p.postSel)
            .put("labels", JSONArray(LABELS))
        return JS.replace("__CFG__", cfg.toString())
    }

    // Idempotent: re-injecting only updates the config.
    private const val JS = """(function(){
var C=__CFG__,K='__hush';
if(!document.documentElement)return;
if(window[K]){window[K].c=C;window[K].run();return}
var st=document.createElement('style');document.documentElement.appendChild(st);
var o={c:C,run:function(){
  var c=o.c;
  st.textContent=(c.shorts?c.shortsCss:'')+(c.ads?c.adsCss:'');
  if(c.shorts&&c.shortsPath&&new RegExp(c.shortsPath).test(location.pathname)){location.replace('/');return}
  if(c.ads&&c.postSel){
    document.querySelectorAll(c.postSel).forEach(function(n){
      var k=(+n.dataset.hushN||0)+1; if(k>3)return; n.dataset.hushN=k;
      var all=n.querySelectorAll('span,div,a');
      for(var i=0;i<all.length;i++){var e=all[i];
        if(!e.firstElementChild&&c.labels.indexOf((e.textContent||'').trim().toLowerCase())>=0){n.style.display='none';break}}
    });
  }
}};
window[K]=o;
var t=0;
new MutationObserver(function(){clearTimeout(t);t=setTimeout(o.run,300)}).observe(document.documentElement,{childList:true,subtree:true});
setInterval(o.run,1000);o.run();
})();"""
}
