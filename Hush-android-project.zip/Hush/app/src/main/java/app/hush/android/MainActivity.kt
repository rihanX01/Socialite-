package app.hush.android

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject

/** Home screen: a local HTML page (assets/ui/index.html) talking to this class. */
class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private lateinit var store: Store

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            setBackgroundColor(0xFF16142A.toInt())
            addJavascriptInterface(Bridge(), "Android")
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?) = true
            }
            loadUrl("file:///android_asset/ui/index.html")
        }
        setContentView(FrameLayout(this).apply {
            fitsSystemWindows = true
            setBackgroundColor(0xFF16142A.toInt())
            addView(web)
        })
    }

    override fun onResume() {
        super.onResume()
        web.evaluateJavascript("window.refresh&&refresh()", null)
    }

    private fun stateJson(): String {
        val arr = JSONArray()
        var total = 0
        for (p in Platforms.all) {
            val used = store.usedSec(p.id)
            total += used
            arr.put(
                JSONObject().put("id", p.id).put("name", p.name).put("color", p.color)
                    .put("limit", store.limit(p.id)).put("used", used)
                    .put("shortsLabel", p.shortsLabel)
                    .put("shorts", store.flag(p.id, "shorts")).put("ads", store.flag(p.id, "ads"))
                    .put("blocked", store.blockReason(p.id) != null)
            )
        }
        return JSONObject().put("platforms", arr).put("totalSec", total)
            .put("downtime", JSONObject().put("on", store.downtimeOn).put("start", store.dtStart).put("end", store.dtEnd))
            .toString()
    }

    // Only this local page gets the bridge. Social sites never see it.
    inner class Bridge {
        @JavascriptInterface fun state(): String = stateJson()
        @JavascriptInterface fun open(id: String) {
            runOnUiThread { startActivity(Intent(this@MainActivity, SiteActivity::class.java).putExtra("id", id)) }
        }
        @JavascriptInterface fun setLimit(id: String, minutes: Int) = store.setLimit(id, minutes)
        @JavascriptInterface fun setFlag(id: String, key: String, on: Boolean) = store.setFlag(id, key, on)
        @JavascriptInterface fun setDowntime(on: Boolean, start: Int, end: Int) {
            store.downtimeOn = on; store.dtStart = start; store.dtEnd = end
        }
    }
}
