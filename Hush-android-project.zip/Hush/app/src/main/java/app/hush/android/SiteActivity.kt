package app.hush.android

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity

/** One social site in a clean WebView, with usage timing, limit and downtime enforcement. */
class SiteActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private lateinit var store: Store
    private lateinit var p: Platform
    private lateinit var status: TextView
    private val handler = Handler(Looper.getMainLooper())
    private var since = 0L
    private var blocked = false

    private val tick = object : Runnable {
        override fun run() { commit(); check(); handler.postDelayed(this, 5000) }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        p = Platforms.byId(intent.getStringExtra("id") ?: "") ?: run { finish(); return }

        val bg = 0xFF16142A.toInt()
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(4), dp(2), dp(16), dp(2))
        }
        val close = TextView(this).apply {
            text = "✕"; textSize = 18f; setTextColor(Color.WHITE)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setOnClickListener { finish() }
        }
        val title = TextView(this).apply {
            text = p.name; textSize = 16f; setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        status = TextView(this).apply { textSize = 13f; setTextColor(0xFF9D98C2.toInt()) }
        bar.addView(close); bar.addView(title); bar.addView(status)

        web = WebView(this)
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            // Plain mobile-Chrome identity; avoids "open in app" nags on some sites.
            userAgentString = userAgentString.replace("; wv", "").replace(" Version/4.0", "")
        }
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val u = request?.url ?: return true
                if (u.scheme == "hush") { finish(); return true }
                if (u.scheme != "http" && u.scheme != "https") return true
                val host = u.host ?: return true
                if (p.hosts.any { host == it || host.endsWith(".$it") }) return false
                try { startActivity(Intent(Intent.ACTION_VIEW, u)) } catch (_: Exception) {}
                return true
            }
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) = inject()
            override fun onPageFinished(view: WebView?, url: String?) = inject()
            override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) = inject()
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            fitsSystemWindows = true
            setBackgroundColor(bg)
            addView(bar)
            addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        })

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { if (!blocked && web.canGoBack()) web.goBack() else finish() }
        })

        if (store.blockReason(p.id) != null) showBlocked() else web.loadUrl(p.url)
    }

    private fun inject() {
        if (blocked) return
        web.evaluateJavascript(Platforms.script(p, store.flag(p.id, "shorts"), store.flag(p.id, "ads")), null)
    }

    private fun commit() {
        val now = SystemClock.elapsedRealtime()
        if (blocked) { since = now; return }
        val s = ((now - since) / 1000).toInt()
        if (s > 0) { store.addUsed(p.id, s); since += s * 1000L }
    }

    private fun check() {
        if (!blocked && store.blockReason(p.id) != null) showBlocked()
        val lim = store.limit(p.id)
        val min = store.usedSec(p.id) / 60
        status.text = if (lim > 0) "${maxOf(lim - min, 0)}m left" else "${min}m today"
    }

    private fun showBlocked() {
        blocked = true
        val why = if (store.inDowntime()) "Downtime is on" else "Daily limit reached"
        val html = """<meta name="viewport" content="width=device-width,initial-scale=1">
<body style="margin:0;height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;background:#16142a;color:#ece9f7;font-family:serif;text-align:center;padding:24px;box-sizing:border-box">
<h2 style="font-weight:400;font-size:28px;margin:0 0 8px">$why</h2>
<p style="color:#9d98c2;font-family:sans-serif;margin:0">${p.name} is closed for now.</p>
<a href="hush://close" style="margin-top:28px;padding:12px 30px;border-radius:999px;background:#8fe3cf;color:#16142a;text-decoration:none;font-family:sans-serif;font-weight:600">Close</a>"""
        web.loadDataWithBaseURL(null, html, "text/html", "utf-8", null)
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
        since = SystemClock.elapsedRealtime()
        handler.post(tick)
    }

    override fun onPause() {
        commit()
        handler.removeCallbacks(tick)
        web.onPause() // stops background audio/video, so time spent is honest
        super.onPause()
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }
}
