package app.hush.android

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Everything lives on-device in SharedPreferences. No account, no network calls. */
class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("hush", Context.MODE_PRIVATE)

    private fun day() = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())

    init { // keep only today's usage counters
        val old = sp.all.keys.filter { it.startsWith("used_") && !it.startsWith("used_${day()}_") }
        if (old.isNotEmpty()) {
            val e = sp.edit()
            old.forEach { e.remove(it) }
            e.apply()
        }
    }

    fun limit(id: String) = sp.getInt("limit_$id", 0) // minutes, 0 = no limit
    fun setLimit(id: String, m: Int) = sp.edit().putInt("limit_$id", m.coerceIn(0, 1440)).apply()

    fun flag(id: String, k: String) = sp.getBoolean("flag_${id}_$k", true)
    fun setFlag(id: String, k: String, v: Boolean) = sp.edit().putBoolean("flag_${id}_$k", v).apply()

    fun usedSec(id: String) = sp.getInt("used_${day()}_$id", 0)
    fun addUsed(id: String, s: Int) = sp.edit().putInt("used_${day()}_$id", usedSec(id) + s).apply()

    var downtimeOn: Boolean
        get() = sp.getBoolean("dt_on", false)
        set(v) { sp.edit().putBoolean("dt_on", v).apply() }
    var dtStart: Int // minutes after midnight
        get() = sp.getInt("dt_start", 22 * 60)
        set(v) { sp.edit().putInt("dt_start", v).apply() }
    var dtEnd: Int
        get() = sp.getInt("dt_end", 7 * 60)
        set(v) { sp.edit().putInt("dt_end", v).apply() }

    fun inDowntime(): Boolean {
        if (!downtimeOn) return false
        val c = Calendar.getInstance()
        val now = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
        return if (dtStart <= dtEnd) now in dtStart until dtEnd else now >= dtStart || now < dtEnd
    }

    /** null = open, otherwise "downtime" or "limit". */
    fun blockReason(id: String): String? = when {
        inDowntime() -> "downtime"
        limit(id) > 0 && usedSec(id) >= limit(id) * 60 -> "limit"
        else -> null
    }
}
